
<?php

/* Database credentials. Assuming you are running MySQL

server with default setting (user 'root' with no password) */

$DB_SERVER = "localhost";

$DB_USERNAME = "id12910157_emandiapp";

$DB_PASSWORD = "emandi@123";

$DB_NAME = "id12910157_emandi";



/* Attempt to connect to MySQL database */

$link = mysqli_connect($DB_SERVER, $DB_USERNAME, $DB_PASSWORD, $DB_NAME);

// Check connection

if($link === false){

die("ERROR: Could not connect. " . mysqli_connect_error());

}

?>


